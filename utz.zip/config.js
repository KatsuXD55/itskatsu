/*
   * Base Simpel
   * Created By Siputzx Production 
*/

const Styles = (text, style = 1) => {
  var xStr = 'abcdefghijklmnopqrstuvwxyz1234567890'.split('');
  var yStr = {
    1: 'ᴀʙᴄᴅᴇꜰɢʜɪᴊᴋʟᴍɴᴏᴘqʀꜱᴛᴜᴠᴡxʏᴢ1234567890'
  };
  var replacer = [];
  xStr.map((v, i) =>
    replacer.push({
      original: v,
      convert: yStr[style].split('')[i]
    })
  );
  var str = text.toLowerCase().split('');
  var output = [];
  str.map((v) => {
    const find = replacer.find((x) => x.original == v);
    find ? output.push(find.convert) : output.push(v);
  });
  return output.join('');
};

global.owner = [
  "6285878178292",]
global.botname = '𝐊𝐚𝐭𝐬𝐮𝐌𝐃'
global.ownername = '𝐢𝐭𝐬𝐊𝐚𝐭𝐬𝐮𝐗𝐃'
global.namaowner = '𝐢𝐭𝐬𝐊𝐚𝐭𝐬𝐮𝐗𝐃'

//========FEATURE PANEL===========\\
global.footer2 = Styles('simple whatsapp bot made by 𝐢𝐭𝐬𝐊𝐚𝐭𝐬𝐮𝐗𝐃')
global.domain = 'https://www.shopwebsite.my.id' // Isi Domain Lu
global.apikey = 'ptla_RiorGCs91ApHWYqcEi1T3tUe2erF1SDcfiXXvYRgnyR' // Isi Apikey Plta Lu
global.capikey = 'ptlc_JWFavwaVsuPyn3unGXCJjec6RvqiIPw0V2ZZzyFGMG6' // Isi Apikey Pltc Lu
global.eggsnya = '15' // id eggs yang dipakai
global.location = '1' // id location
//=========FINIS==================\\


let fs = require('fs')
let file = require.resolve(__filename)
fs.watchFile(file, () => {
fs.unwatchFile(file)
console.log(`Update ${__filename}`)
delete require.cache[file]
require(file)
})